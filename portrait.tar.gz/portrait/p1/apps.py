from django.apps import AppConfig


class P1Config(AppConfig):
    name = 'p1'
