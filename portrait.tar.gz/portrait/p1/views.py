from django.shortcuts import render
from django.http import HttpResponse
from p1.models import posts
# Create your views here.

def index(request):
    if(request.method=='POST'):
        return HttpResponse("POST request received by server")
    return render(request, 'index.html')
